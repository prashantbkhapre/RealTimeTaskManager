﻿using Microsoft.AspNetCore.SignalR;

namespace RealTimeTaskManagerAPI.Model
{
    public class BroadcastHub : Hub<IHubClient>
    {
    }
}
