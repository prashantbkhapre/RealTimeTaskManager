﻿namespace RealTimeTaskManagerAPI.Model
{
    public class NotificationCountResult
    {
        public int Count { get; set; }
    }
}
