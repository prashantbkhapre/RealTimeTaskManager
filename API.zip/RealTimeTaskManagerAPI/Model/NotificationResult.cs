﻿namespace RealTimeTaskManagerAPI.Model
{
    public class NotificationResult
    {
        public string EmployeeName { get; set; }
        public string TranType { get; set; }
    }
}
