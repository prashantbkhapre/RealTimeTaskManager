﻿namespace RealTimeTaskManagerAPI.Model
{
    public interface IHubClient
    {
        Task BroadcastMessage();
    }
}
