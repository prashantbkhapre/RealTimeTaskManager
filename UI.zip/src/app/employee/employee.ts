export interface Employee {
    id: string,  
    name: string,  
    address: string,  
    gender: string,  
    company: string,  
    designation: string,  
    cityname: string  
}
