export class NotificationCountResult {  
    count!: number;  
}  
  
export class NotificationResult {  
    employeeName!: string;  
    tranType!: string;  
}  